# 顺风方块核心资产包

所有图片为 PNG。背景为 RGB；其余图片为 RGBA，均包含真实透明像素。

| 文件 | 用途 | 尺寸 |
| --- | --- | --- |
| backgrounds/gameplay_garden.png | 对局背景 | 941 × 1672 |
| boards/board_cream.png | 棋盘底板（light 为简化样式） | 1254 × 1254 |
| boards/board_cream_light.png | 棋盘底板（light 为简化样式） | 1283 × 1226 |
| buttons/icon_round_disabled.png | 通用圆形图标按钮底图 / disabled | 1254 × 1254 |
| buttons/icon_round_normal.png | 通用圆形图标按钮底图 / normal | 1293 × 1216 |
| buttons/icon_round_pressed.png | 通用圆形图标按钮底图 / pressed | 1294 × 1216 |
| buttons/primary_green_disabled.png | 绿色主按钮 / disabled | 2172 × 724 |
| buttons/primary_green_normal.png | 绿色主按钮 / normal | 2172 × 724 |
| buttons/primary_green_pressed.png | 绿色主按钮 / pressed | 2172 × 724 |
| buttons/secondary_cream_disabled.png | 奶油次按钮 / disabled | 2172 × 724 |
| buttons/secondary_cream_normal.png | 奶油次按钮 / normal | 2172 × 724 |
| buttons/secondary_cream_pressed.png | 奶油次按钮 / pressed | 2172 × 724 |
| buttons/video_gold_disabled.png | 金色视频奖励按钮 / disabled | 2172 × 724 |
| buttons/video_gold_normal.png | 金色视频奖励按钮 / normal | 2172 × 724 |
| buttons/video_gold_pressed.png | 金色视频奖励按钮 / pressed | 2172 × 724 |

## 接入注意

- 圆形按钮是空白底图，返回、设置、重来、提示、暂停图标需要另行叠加。
- 三态为独立生成，特别是圆形按钮的画布尺寸、透明留白和主体大小不一致，切换前须调整 SpriteFrame 的裁切、锚点和显示大小，检查是否跳动。
- 部分透明边缘存在彩色杂点和晕边，需在深浅背景检查并清理。阴影已烘焙；九宫格切片参数需在 Cocos 中按实际边缘调试，未经过验证。
- 轻量版表示视觉样式简化，不代表文件体积已优化；其画布不是正方形。背景适配不同屏幕时留意裁切和安全区。
- 资产尚未在 Cocos 或微信、抖音真机中验证；需验证压缩、透明边缘、状态切换、布局与性能。
